<?php
return [
    'cn' => '繁',
    'en' => 'ENG',
];
