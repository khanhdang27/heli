<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubjectTranslation extends Model
{
    protected $guarded = [];
    protected $table = 'subject_translations';
}
