<div class="pt-3 reviews">
    <div class="row">
        <div class="col-sm">
            <div>
                <img class="ava-responsive" height="514" src="{{ asset("images/ava.jpg") }}">
            </div>
        </div>
        <div class="col-sm d-flex flex-column justify-content-end">
            <div class="name-tutor text-primary">{{ $courseDetail->tutor->full_name }}</div>
            <div class="position-tutor text-primary">Tutor/Admission Consultant</div>
        </div>
    </div>
    <div class="mt-5 container-fluid content-info text-primary">
        <div class="mb-5">
            {{ $courseDetail->tutor->tutor_info }}
        </div>
        <div>
            ► {{ $courseDetail->tutor->tutor_level }}
        </div>
        <div>
            ► {{ $courseDetail->tutor->tutor_specialized }}
        </div>
        <div>
            ► {{ $courseDetail->tutor->tutor_experience }}
        </div>
    </div>
</div>
