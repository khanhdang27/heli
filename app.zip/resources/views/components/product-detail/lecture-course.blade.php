@php
    $videoLink = "https://player.vimeo.com/video/".$videoId."?title=0&amp;byline=0&amp;portrait=0&amp;speed=0&amp;badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=217713"    
@endphp

<iframe src={{$videoLink}} width="840" height="420" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen title="Default name"></iframe>
