<div class="banner-content">
    <img src="{{asset("images/banner.jpg")}}">
    <div class="banner-info">
        <div class="banner-caption text-secondary">
            <p class="m-0">太陽神教育網上課程</p>
            <p> 全面協助你的升學計畫</p>
        </div>
        <div class="btn-register-free">
            <button class="btn-register-now mt-5 free btn-secondary text-primary" data-toggle="modal"
                    data-target="#registerModal">
                @lang('keywords.registerNowFree')
            </button>
        </div>
    </div>
</div>
