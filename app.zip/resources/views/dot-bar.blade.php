<div class="dot-bar">
    @for ($i = 0; $i < 8; $i++)
        <div class='list-dot bg-secondary'>
        </div>
    @endfor
</div>
