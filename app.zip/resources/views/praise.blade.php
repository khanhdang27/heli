<div class="position-relative ml-auto mr-auto shadow">
    <div class="avatar-guest position-absolute">
        <img class="avatar text-center w-100" src="images/ava1.jpg">
    </div>
    <div class="card content-praise text-primary border-0">
        <div class="card-body p-0">
            <p class="text-center">“The consultants from Helios help refine my personal statement for UCAS and JUPAS. I
                would not have admitted
                to such a reputable academy without their assistance. Life in London is beautiful but challenging, yet
                the
                mentors arranged by Helios are really helpful in different means.”</p>
            <div>
                J.C
                <br/>
                Oxford
            </div>

        </div>
    </div>
</div>
