<div>
    <button onclick="myFunction()">Click me</button>
        Upload Files to Drive
    </button>
</div>

<script>

</script>
