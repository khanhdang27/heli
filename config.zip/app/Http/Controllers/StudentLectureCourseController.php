<?php

namespace App\Http\Controllers;

use App\StudentLectureCourse;
use Illuminate\Http\Request;

class StudentLectureCourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StudentLectureCourse  $studentLectureCourse
     * @return \Illuminate\Http\Response
     */
    public function show(StudentLectureCourse $studentLectureCourse)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StudentLectureCourse  $studentLectureCourse
     * @return \Illuminate\Http\Response
     */
    public function edit(StudentLectureCourse $studentLectureCourse)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StudentLectureCourse  $studentLectureCourse
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StudentLectureCourse $studentLectureCourse)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StudentLectureCourse  $studentLectureCourse
     * @return \Illuminate\Http\Response
     */
    public function destroy(StudentLectureCourse $studentLectureCourse)
    {
        //
    }
}
