<?php

namespace App\Http\Controllers;

use App\Models\MembershipCourse;
use Illuminate\Http\Request;

class MembershipCourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MembershipCourse  $membershipCourse
     * @return \Illuminate\Http\Response
     */
    public function show(MembershipCourse $membershipCourse)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MembershipCourse  $membershipCourse
     * @return \Illuminate\Http\Response
     */
    public function edit(MembershipCourse $membershipCourse)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MembershipCourse  $membershipCourse
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MembershipCourse $membershipCourse)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MembershipCourse  $membershipCourse
     * @return \Illuminate\Http\Response
     */
    public function destroy(MembershipCourse $membershipCourse)
    {
        //
    }
}
